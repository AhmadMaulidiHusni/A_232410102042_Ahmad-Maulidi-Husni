﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace UtsPbo
{
    public partial class RegisterMahasiswa : Form
    {
        List<Mahasiswa> listMahasiswa = new List<Mahasiswa>();

        public RegisterMahasiswa()
        {
            InitializeComponent();
            ////Mahasiswa mahasiswa = new Mahasiswa();
            //mahasiswa.nama = "Ahmad Maulidi Husni";
            //mahasiswa.nim = "232410102042";
            //mahasiswa.email = "ahmadmaulidi08.maul@gmail.com";
            //mahasiswa.password = "Dani0504";

            //listMahasiswa.Add(mahasiswa);
            
        }

        private void btnDaftar_Click(object sender, EventArgs e)
        {
            LoginMahasiswa masukmhs = new LoginMahasiswa();
            masukmhs.ShowDialog();
        }

        public class Mahasiswa
        {
            public string nama {  get; set; }
            public string nim { get; set; }
            public string email {  get; set; }
            public string nohp {  get; set; }
            public string password {  get; set; }

            public Mahasiswa(string Nama, string Nim, string Email, string Nohp, string Password)
            {
                this.nama = Nama;
                this.nim = Nim;
                this.email = Email;
                this.nohp = Nohp;
                this.password = Password;
            }
        }
    }
}
