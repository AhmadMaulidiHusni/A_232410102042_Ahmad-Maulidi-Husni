﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UtsPbo
{
    public partial class RegisterDosen : Form
    {
        public RegisterDosen()
        {
            InitializeComponent();
        }

        private void btnDaftar_Click(object sender, EventArgs e)
        {
            LoginDosen loginDosen = new LoginDosen();
            loginDosen.ShowDialog();
        }
    }
}
