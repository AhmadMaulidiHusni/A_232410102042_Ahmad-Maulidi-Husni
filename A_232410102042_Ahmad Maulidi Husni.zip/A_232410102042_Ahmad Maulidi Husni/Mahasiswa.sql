-- Table: public.Mahasiswa

-- DROP TABLE IF EXISTS public."Mahasiswa";

CREATE TABLE IF NOT EXISTS public."Mahasiswa"
(
    "Nama " character(50) COLLATE pg_catalog."default",
    "Nim" integer,
    "Email" character(50) COLLATE pg_catalog."default",
    "No Hp" character(50) COLLATE pg_catalog."default",
    "Password" character(50) COLLATE pg_catalog."default"
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Mahasiswa"
    OWNER to postgres;