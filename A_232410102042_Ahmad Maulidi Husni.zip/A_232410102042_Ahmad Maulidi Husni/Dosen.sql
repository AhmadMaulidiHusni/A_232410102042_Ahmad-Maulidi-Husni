-- Table: public.Dosen

-- DROP TABLE IF EXISTS public."Dosen";

CREATE TABLE IF NOT EXISTS public."Dosen"
(
    "Nama" character(50) COLLATE pg_catalog."default",
    "Email" character(50) COLLATE pg_catalog."default",
    "No Identitas" integer,
    "No Hp" character(50) COLLATE pg_catalog."default",
    "Password" character(50) COLLATE pg_catalog."default"
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS public."Dosen"
    OWNER to postgres;